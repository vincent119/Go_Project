This code is used by the demo - build under renderview/cmd/demo.
