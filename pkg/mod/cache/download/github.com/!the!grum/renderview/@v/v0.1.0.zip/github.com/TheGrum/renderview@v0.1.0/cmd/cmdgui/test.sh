#!/bin/sh
./cmdgui "./plot" "'tan(x); x' {{$.left}} {{$.right}} {{$.top}} {{$.bottom}}"
